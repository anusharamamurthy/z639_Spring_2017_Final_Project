import string
import pandas as pd
import datetime
import math
from collections import Counter
from dbMethods import SQldb

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer

from sklearn.neighbors import NearestNeighbors

stop_words = ['a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are',
                      'arent', 'as',
                      'at', 'because', 'be', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by', 'cant',
                      'cannot', 'couldnt', 'did', 'didnt', 'do', 'does', 'doesnt', 'doing', 'dont', 'down', 'during',
                      'each', 'few', 'for',
                      'from', 'further', 'had', 'hadnt', 'has', 'hasnt', 'have', 'havent', 'having', 'he', 'hed',
                      'hell', 'hes', 'her',
                      'hers', 'here', 'heres', 'herself', 'him', 'himself', 'his', 'how', 'hows', 'i', 'id', 'ill',
                      'im', 'ive', 'if', 'in',
                      'into', 'is', 'isnt', 'it', 'its', 'itself', 'lets', 'more', 'me', 'most', 'mustnt', 'my',
                      'myself', 'no', 'nor', 'not', 'of',
                      'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'ours', 'ourselves', 'out', 'over',
                      'own', 'same', 'shant', 'she',
                      'shell', 'shed', 'shes', 'should', 'shouldnt', 'so', 'some', 'such', 'than', 'that', 'thats',
                      'the', 'their', 'theirs', 'them',
                      'themselves', 'then', 'there', 'theres', 'they', 'theyd', 'theyll', 'theyre', 'theyve', 'this',
                      'those', 'though', 'through',
                      'to', 'too', 'under', 'until', 'up', 'very', 'was', 'wasnt', 'we', 'wed', 'well', 'were', 'weve',
                      'werent', 'what', 'whats',
                      'when', 'whens', 'where', 'wheres', 'which', 'while', 'who', 'whos', 'whom', 'why', 'whys',
                      'with', 'wont', 'would', 'wouldnt',
                      'you', 'youd', 'youll', 'youre', 'youve', 'your', 'yours', 'yourself', 'yourselves', 'font',
                      'html', 'table', 'br', 'will',
                      'article', 'says', 'can', 'one', 'use', 'writes']
flatten = lambda l: [item for sublist in l for item in sublist]

class Utilities:

    def __init__(self):
        self.db = SQldb()

    def sanitize_content(self,content):

        content = content.lower()
        rmv_chars = string.punctuation + '\t\n'
        translator = str.maketrans('', '', rmv_chars)
        content = content.translate(translator)
        sanitized_content = [word for word in content.split() if word not in stop_words and len(word) > 2]
        return sanitized_content

    def list_empty_reviews(self,df):

        no_text = len(df[df['reviewText'] == ""])/len(df['reviewText'].unique())
        print("% of Reviews that have no review Text: {:.2f}".format(no_text*100))

        no_name = len(df['reviewerID'][df['reviewerName'].isnull() == True].unique())/len(df['reviewerID'].unique())
        print("% of Reviewers that have no name: {:.2f}".format(no_name*100))
        # no_rating = len(df[df['overall'].isnull() == True]) / len(df)
        # print("% of Reviews that have no rating: {:.2f}".format(no_rating * 100))

    def parse_df(self,df):

        grp_df = df.assign(santize_content=df['reviewText'].map(self.sanitize_content))
        # grp_df['reviewTime'] = pd.to_datetime(grp_df['reviewTime'])
        return grp_df

    def group_df(self,df):

        grouped_reviewer = df.groupby(by=['reviewerID', 'unixReviewTime'])
        grouped_df = pd.DataFrame(grouped_reviewer.size())
        dict_data = grouped_df.to_dict()[0]
        for each, value in dict_data.items():
            self.db.insertReview(str(each[0]),str(datetime.datetime.utcfromtimestamp(each[1])).split(" ")[0],str(value),category="Musical_Instruments")

    def insert_reviewer_info(self,df,ctg):

        grouped_reviewer = df.groupby(by=['reviewerID', 'unixReviewTime'])
        grouped_df = pd.DataFrame(grouped_reviewer.size()).to_dict()[0]
        for each,val in grouped_df.items():
            self.db.insertReview(str(each[0]),
                str(str(datetime.datetime.utcfromtimestamp(each[1])).split(" ")[0]),str(val),category=ctg)

    def displayReviewTable(self):
        self.db.select_one_time_reviewers()

    def get_short_reviews(self,df):

        flagged_df = df.assign(santize_content=df['reviewText'].map(self.sanitize_content))
        reviews = []
        sc_lst= []
        ratings = []
        for sc,rev_text,rating in df[['santize_content','reviewText','overall']].values:
            if len(sc) < 6 and  len(sc) > 0:
                sc_lst.append(sc)
                # reviews.append(rev_text)
                ratings.append(rating)
        print("Short Reviews")
        print("Size of short reviews:{:.2f}".format(len(ratings)/len(df)*100))
        print("Average rating:{:.2f}".format(sum(ratings)/len(ratings)))
        # return reviews
        # print(flatten(sc_lst))

    def get_onetime_reviewers(self,df,cat):

        flag_ids = self.db.select_one_time_reviewers(cat)

        rating_median = df['overall'][df['reviewerID'].isin(flag_ids)].median()
        # flagged_reviews = df['reviewText'][df['reviewerID'].isin(flag_ids)].tolist()
        # for e in flagged_reviews:
        #     print(e)

        print('Reviewers who appear exactly once in the data set')
        print("Size of reviews:{:.2f}".format(len(flag_ids) / len(df) * 100))
        print("Average rating:{:.2f}".format(rating_median))
        # return flagged_reviews

    def get_max_reviews(self,df,cat):

        flag_ids = self.db.select_max_review_counts(cat)

        rating_median = df['overall'][df['reviewerID'].isin(flag_ids)].median()
        # flagged_reviews = df['reviewText'][df['reviewerID'].isin(flag_ids)].tolist()

        # for e in flagged_reviews:
        #     print(e)
        # return flagged_reviews
        print("Top 10 Reviewers who have the largest number of reviews")
        print("Size of reviews:{:.2f}".format(len(flag_ids) / len(df) * 100))
        print("Average rating:{:.2f}".format(rating_median))

    def get_least_reviews(self,df,cat):

        flag_ids = self.db.select_least_review_counts(cat)

        # Retired
        # print(flag_ids)
        # ratings = []
        # flagged_reviews = []

        # for x in flag_ids:
        #     # flagged_reviews.append(df['reviewText'][df['reviewerID'] == x].tolist())
        #     ratings.append(df['overall'][df['reviewerID'] == x].median())

        rating_median = df['overall'][df['reviewerID'].isin(flag_ids)].median()
        # flagged_reviews = df['reviewText'][df['reviewerID'].isin(flag_ids)].tolist()

        # for e in flagged_reviews:
        #     print(e)
        # return flagged_reviews
        print("Reviewers who appear to write only one review a day")
        print("Size of reviews:{:.2f}".format(len(flag_ids) / len(df) * 100))
        print("Average rating:{:.2f}".format(rating_median))


    def get_neighbors(self,df,cat):

        train = df.sample(frac=0.4,random_state=10)

        test = self.get_onetime_reviewers(df,cat)

        count_vect = CountVectorizer()
        X_train_counts = count_vect.fit_transform(train['reviewText'])
        tfidf_transformer = TfidfTransformer(sublinear_tf=True)
        X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)


        flat_test = flatten(test)
        X_new_counts = count_vect.transform(flat_test)
        X_new_tfidf = tfidf_transformer.transform(X_new_counts)

        neigh = NearestNeighbors(n_neighbors=4)
        neigh.fit(X_train_tfidf)
        nlist = neigh.kneighbors(X_new_tfidf, return_distance=False)
        flat_nlist = flatten(nlist)
        for x in set(flat_nlist):
            print(df.iloc[x]['reviewText'])











