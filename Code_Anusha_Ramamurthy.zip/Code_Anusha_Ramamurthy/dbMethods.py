import sqlite3,os
import datetime

class SQldb:

    def __init__(self):
        self.db_file_name = "database.txt"
        self.db_con = sqlite3.connect(self.db_file_name)
        self.cursor = self.db_con.cursor()
        # self.createReviewTable()

    def createReviewTable(self):
        SQL = """CREATE TABLE Review(ID INTEGER PRIMARY KEY AUTOINCREMENT, ReviewerID VARCHAR (30) NOT NULL,
                ReviewTime DATETIME, ReviewCount INT NOT NULL, Category varchar(20) NOT NULL);"""

    def insertReview(self, rev_id, rev_time, cnt, category):

        SQL = "INSERT INTO Review(ReviewerID, ReviewTime, ReviewCount, Category)"
        SQL += "VALUES ('" + rev_id + "','" + rev_time + "','" + cnt + "','" + category + "');"
        self.cursor.execute(SQL)
        self.db_con.commit()

    def select_one_time_reviewers(self,category):

        if self.db_file_name not in os.listdir(os.curdir):
            print("No database present")
            return None

        SQL = "select ReviewerID from Review group by ReviewerID"
        SQL += " having count(*) = 1 and Category like '" + category + "';"
        self.cursor.execute(SQL)
        results = self.cursor.fetchall()

        rID_list = []
        for result in results:
            rID_list.append(result[0])

        return rID_list

    def select_max_review_counts(self,category):

        if self.db_file_name not in os.listdir(os.curdir):
            print("No database present")
            return None

        SQL = "Select  ReviewerID from Review group by"
        SQL += " ReviewerID having ReviewCount > 3 and Category like '" + category + "'"
        SQL += " order by ReviewCount desc limit 10 ;"
        self.cursor.execute(SQL)
        results = self.cursor.fetchall()

        rID_list = []
        for result in results:
            rID_list.append(result[0])

        return rID_list

    def select_least_review_counts(self,category):

        if self.db_file_name not in os.listdir(os.curdir):
            print("No database present")
            return None

        SQL = "select ReviewerID from Review group by ReviewerID having ReviewCount = 1"
        SQL += " and Category like '" + category + "';"
        self.cursor.execute(SQL)
        results = self.cursor.fetchall()

        rID_list = []
        for result in results:
            rID_list.append(result[0])

        return rID_list
