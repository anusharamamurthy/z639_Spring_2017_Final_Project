import pandas as pd
import random
import matplotlib.pyplot as plt
import seaborn as sns


def draw_histogram_plot(df,col):

    # plt.show()
    # sns.despine()
    # plt.title("Histogram of ratings in Beauty Products")

    g = sns.countplot(x=col, data=df)
    sns.set_context("poster")
    # remove the top and right line in graph
    sns.despine()

    # Set the size of the graph from here
    g.figure.set_size_inches(8, 8)
    # Set the Title of the graph from here
    g.axes.set_title('Distribution of Ratings - Musical Instruments', fontsize=10, alpha=0.5)
    # Set the xlabel of the graph from here
    g.set_xlabel("Rating", size=10)
    # Set the ylabel of the graph from here
    g.set_ylabel("Count", size=10)
    # Set the ticklabel size and color of the graph from here
    g.tick_params(labelsize=8, labelcolor="black")

    plt.show(g)
