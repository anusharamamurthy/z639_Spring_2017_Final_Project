import pandas as pd
import gzip,pickle,os
from utilities import Utilities
import graphs as g

#     source http://jmcauley.ucsd.edu/data/amazon/
def parse(path):
    g = gzip.open(path, 'rb')
    for l in g:
        yield eval(l)

def getDF(path):
    i = 0
    df = {}
    for d in parse(path):
        df[i] = d
        i += 1
    return pd.DataFrame.from_dict(df, orient='index')


def pickle_df(df_file_name,df):
    """
    :param file_name:name of file to be pickled 
    :return None: 
    """

    pkl = open(df_file_name, 'wb')
    pickle.dump(df, pkl)
    pkl.close()


def unpickle_df(file_name):
    """
    :param file_name: pickled file
    :return None: 
    """

    pkl = open(file_name, 'rb')
    df = pickle.load(pkl)
    pkl.close()
    return df

if __name__ == '__main__':
    #
    # b_file_name = 'data/reviews_Beauty_5.json.gz'
    # b_df_name = "reviews_Beauty_5.pkl"

    file_name = 'data/reviews_Musical_Instruments_5.json.gz'
    df_name = "reviews_Musical_Instruments_5.pkl"
    utils = Utilities()

    # if df_name not in os.listdir(os.curdir):
    #     rdf = getDF(file_name)
    #     rfrmt_df = utils.parse_df(rdf)
    #     pickle_df(df_name,rfrmt_df)
    #
    #     rdf = getDF(file_name)
    #     rfrmt_df = utils.parse_df(rdf)
    #     pickle_df(df_name, rfrmt_df)
    # else:
    r_df = unpickle_df(df_name) #musical
    # b_df = unpickle_df(b_df_name) #beauty

    # only on first run!!
    # utils.insert_reviewer_info(b_df, "Beauty")
    # utils.insert_reviewer_info(r_df,"Music")

    # utils.get_neighbors(df)


    # For Analysis of Musical Reviews Category
    utils.list_empty_reviews(r_df)
    utils.get_short_reviews(r_df)
    utils.get_onetime_reviewers(r_df,"Musical_Instruments")
    utils.get_least_reviews(r_df,"Musical_Instruments")
    utils.get_max_reviews(r_df,"Musical_Instruments")

    # For Analysis of Beauty Reviews Category
    # utils.list_empty_reviews(b_df)
    # utils.get_short_reviews(b_df)
    # utils.get_onetime_reviewers(b_df,"Beauty")
    # utils.get_least_reviews(b_df,"Beauty")
    # utils.get_max_reviews(b_df,"Beauty")

    # Graphs
    g.draw_histogram_plot(r_df,'overall')
    # g.draw_histogram_plot(b_df, 'overall')
